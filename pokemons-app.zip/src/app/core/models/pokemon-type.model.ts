export interface PokemonType {
  id: number;
  name: string;
}
