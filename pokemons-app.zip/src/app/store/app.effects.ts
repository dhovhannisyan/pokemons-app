import { PokemonEffects } from "../pokemons/store/pokemon.effects";

export const appEffects = [ PokemonEffects ];
