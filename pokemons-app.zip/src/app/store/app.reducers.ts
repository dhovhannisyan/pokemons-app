import { pokemonsReducer } from "../pokemons/store/pokemon.reducers";

export const appReducers = {
  pokemons: pokemonsReducer
};
