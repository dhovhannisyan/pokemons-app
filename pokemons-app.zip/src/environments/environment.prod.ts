export const environment = {
  production: true,
  baseUrl: 'https://pokeapi.co/api/v2/'
};
